# BigBang v3.1 Merge Audit

The uploaded reference files are treated as the authoritative pre-enhancement versions.
The previous v3.0 package incorrectly replaced mature references with much shorter summaries.
v3.1 preserves each uploaded original in full and appends/integrates the new mandatory best-practice rules.

| File | Original bytes | Bad v3 bytes | Merged bytes | Original lines | Bad v3 lines | Merged lines | Original preserved |
|---|---:|---:|---:|---:|---:|---:|---|
| hardware-workflow.md | 5007 | 1000 | 7273 | 131 | 21 | 187 | YES |
| project-standards.md | 5761 | 628 | 7817 | 130 | 10 | 191 | YES |
| prompt-and-kickoff-system.md | 10397 | 1295 | 13161 | 325 | 25 | 417 | YES |
| start-from-scratch-workflow.md | 10411 | 906 | 12208 | 280 | 18 | 337 | YES |

## New merged rules

- architecture freeze before downstream generation;
- exact MCU/firmware/platform target lock;
- mandatory START_HERE entrance;
- mandatory per-session Git commit with recorded hash;
- traceable persistent TASKS session ledger;
- safe pause/resume semantics preserved across fresh agent conversations;
- real automatic prompt orchestration with blocking/manual evidence gates;
- no-placeholder completion/release rule;
- demoable final-system acceptance gate;
- skill-maintenance rule: merge mature references; do not replace them with shorter summaries.
